<?php 
	$con=mysqli_connect("localhost","root","","imperial_college");
	if(!$con)
	{
		echo "Connection is not Successfully";
	}
?>